//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////OVERWORLD//////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	
	#ifdef OVERWORLD

		// Lava / Flowing Lava
		if(	mc_Entity.x == 10248) 
			mat=3.0, color.a *=0.40, lmCoord.x += 0.0667, color.rgb *= sqrt(OVERWORLD_LAVA_BRIGHTNESS);

		// Fire / Soul Fire
		if (mc_Entity.x ==  10249 || mc_Entity.x ==10252) 
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(FIRE_BRIGHTNESS_OVERWORLD);

		// Soul CampFire / Soul Fire / Soul Torch
		if (mc_Entity.x == 10210) 
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(SCAMPFIRE_BRIGHTNESS_OVERWORLD);

		// CampFire
		if (mc_Entity.x == 10215) 
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(CAMPFIRE_BRIGHTNESS_OVERWORLD);

		// Lantern
		if (mc_Entity.x == 10251 || mc_Entity.x == 10254) 
			lmCoord.x = 0.860, mat=9.0, color.a *= 1.0, color.rgb *= sqrt(LANTERN_BRIGHTNESS_OVERWORLD);

		// Soul Lantern
		if (mc_Entity.x == 10226 || mc_Entity.x == 10253) 
			lmCoord.x = 0.750, mat = 10.0, color.a *= 1.0,color.rgb *= sqrt(LANTERN_BRIGHTNESS_OVERWORLD);

		// Shroomlight
		if (mc_Entity.x == 10217) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(SHROOMLIGHT_BRIGHTNESS_OVERWORLD);

		// GlowStone
		if (mc_Entity.x == 10231) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(GLOWSTONE_BRIGHTNESS_OVERWORLD);

		// Redstone Lamp
		if (mc_Entity.x == 10218) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(REDSTONE_LAMP_BRIGHTNESS_OVERWORLD);

		// Sea Lantern
		if (mc_Entity.x == 10219) 
			lmCoord.x = 0.85, mat=2.0 , color.a *= 1.0, color.rgb *= sqrt(SEA_LANTERN_BRIGHTNESS_OVERWORLD);

		#ifdef ADVANCED_MATERIALS
			#ifdef REDSTONE_BLOCK_EMISSIVE
			// Redstone Block
			if (mc_Entity.x == 10220 || mc_Entity.x == 10200) 
				lmCoord.x = 0.5, mat=4.0 ,color.a *= 1.0, color.rgb *= sqrt(REDSTONE_BLOCK_BRIGHTNESS_OVERWORLD);
			#endif

			#ifdef LAPISLAZUL_BLOCK_EMISSIVE
			// Lapis Lazuli Block
			if (mc_Entity.x == 10221) 
				lmCoord.x = 0.5, mat=5.0 ,color.a *= 1.0, color.rgb *= sqrt(LAPIS_BLOCK_BRIGHTNESS_OVERWORLD);
			#endif
		#endif

		// Jack O Lantern
		if (mc_Entity.x == 10222) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(JACKOLANTERN_BRIGHTNESS_OVERWORLD);

		// Torch / End Rod
		if (mc_Entity.x == 10214) 
			lmCoord.x = 0.855, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(TORCH_ENDROD_BRIGHTNESS_OVERWORLD);
		
		// Candle
		if (mc_Entity.x == 10257)
			lmCoord.x = 0.855, mat=6.0 ,color.a *= 1.0, color.rgb *= sqrt(CANDLE_BRIGHTNESS_OVERWORLD);

		// Vine Berries
		if (mc_Entity.x == 10256)
			mat=7.0 ,color.a *= 1.0;

		// Spore_Blossom
		if (mc_Entity.x == 10112)
			mat=8.0 ,color.a *= 1.0;

		// lichen
		if (mc_Entity.x == 10255)
			mat=11.0,color.a *= 1.0;

		// Pickle
		if (mc_Entity.x == 10259)
			mat=12.0,color.a *= 1.0;
		
		// Beacon
		if (mc_Entity.x == 10250)
			mat=13.0,color.a *= 1.0;

		// Small Ametyst
		if (mc_Entity.x == 10260)
			mat=14.0,color.a *= 1.0, color.rgb *= sqrt(SMALL_AMETYST_BRIGHTNESS_OVERWORLD);
		// Medium Ametyst
		if (mc_Entity.x == 10261)
			mat=15.0,color.a *= 1.0, color.rgb *= sqrt(MEDIUM_AMETYST_BRIGHTNESS_OVERWORLD);
		// Large Ametyst
		if (mc_Entity.x == 10262)
			mat=16.0,color.a *= 1.0, color.rgb *= sqrt(LARGE_AMETYST_BRIGHTNESS_OVERWORLD);
		// Ametyst Cluster
		if (mc_Entity.x == 10263)
			mat=17.0,color.a *= 1.0, color.rgb *= sqrt(AMETYST_CLUSTER_BRIGHTNESS_OVERWORLD);

	#endif

	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////NETHER/////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	
	#ifdef NETHER

		// Lava / Flowing Lava
		if(	mc_Entity.x == 10248) 
			mat=3.0, color.a *=0.40,lmCoord.x += 0.0667, color.rgb *= sqrt(NETHER_LAVA_BRIGHTNESS);

		// Fire / Soul Fire
		if (mc_Entity.x ==  10249 || mc_Entity.x ==10252)
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(FIRE_BRIGHTNESS_NETHER);

		// Soul CampFire / Soul Fire / Soul Torch
		if (mc_Entity.x == 10210) 
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(SCAMPFIRE_BRIGHTNESS_NETHER);

		// CampFire
		if (mc_Entity.x == 10215) 
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(CAMPFIRE_BRIGHTNESS_NETHER);

		// Lantern
		if (mc_Entity.x == 10251 || mc_Entity.x == 10254) 
			lmCoord.x = 0.860, color.a *= 1.0, color.rgb *= sqrt(LANTERN_BRIGHTNESS_NETHER);

		// Soul Lantern
		if (mc_Entity.x == 10226 || mc_Entity.x == 10253) 
			lmCoord.x = 0.750, color.a *= 1.0, color.rgb *= sqrt(SOUL_LANTERN_BRIGHTNESS_NETHER);

		// Shroomlight
		if (mc_Entity.x == 10217) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(SHROOMLIGHT_BRIGHTNESS_NETHER);

		// GlowStone
		if (mc_Entity.x == 10231) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(GLOWSTONE_BRIGHTNESS_NETHER);

		// Redstone Lamp
		if (mc_Entity.x == 10218) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(REDSTONE_LAMP_BRIGHTNESS_NETHER);

		// Sea Lantern
		if (mc_Entity.x == 10219) 
			lmCoord.x = 0.85, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(SEA_LANTERN_BRIGHTNESS_NETHER);

		#ifdef ADVANCED_MATERIALS
			#ifdef REDSTONE_BLOCK_EMISSIVE
			// Redstone Block
			if (mc_Entity.x == 10220 || mc_Entity.x == 10200) 
				lmCoord.x = 0.5, mat=4.0 ,color.a *= 1.0, color.rgb *= sqrt(REDSTONE_BLOCK_BRIGHTNESS_OVERWORLD);
			#endif
		

			#ifdef LAPISLAZUL_BLOCK_EMISSIVE
			// Lapis Lazuli Block
				if (mc_Entity.x == 10221) 
					lmCoord.x = 0.5, mat=5.0 ,color.a *= 1.0, color.rgb *= sqrt(LAPIS_BLOCK_BRIGHTNESS_OVERWORLD);
			#endif
		#endif
		// Jack O Lantern
		if (mc_Entity.x == 10222) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(JACKOLANTERN_BRIGHTNESS_NETHER);

		// Torch / End Rod
		if (mc_Entity.x == 10214) 
			lmCoord.x = 0.855, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(TORCH_ENDROD_BRIGHTNESS_NETHER);

		// Candle
		if (mc_Entity.x == 10257)
			lmCoord.x = 0.855, mat=6.0 ,color.a *= 1.0, color.rgb *= sqrt(CANDLE_BRIGHTNESS_NETHER);
		
		// Vine Berries
		if (mc_Entity.x == 10256)
			mat=7.0 ,color.a *= 1.0;

		// Spore_Blossom
		if (mc_Entity.x == 10112)
			mat=8.0 , color.a *= 1.0;

		// lichen
		if (mc_Entity.x == 10255)
			mat=11.0,color.a *= 1.0;

		// Pickle
		if (mc_Entity.x == 10259)
			mat=12.0,color.a *= 1.0;

		// Beacon
		if (mc_Entity.x == 10250)
			mat=13.0,color.a *= 1.0;

		// Small Ametyst
		if (mc_Entity.x == 10260)
			mat=14.0,color.a *= 1.0, color.rgb *= sqrt(SMALL_AMETYST_BRIGHTNESS_NETHER);
		// Medium Ametyst
		if (mc_Entity.x == 10261)
			mat=15.0,color.a *= 1.0, color.rgb *= sqrt(MEDIUM_AMETYST_BRIGHTNESS_NETHER);
		// Large Ametyst
		if (mc_Entity.x == 10262)
			mat=16.0,color.a *= 1.0, color.rgb *= sqrt(LARGE_AMETYST_BRIGHTNESS_NETHER);
		// Ametyst Cluster
		if (mc_Entity.x == 10263)
			mat=17.0,color.a *= 1.0, color.rgb *= sqrt(AMETYST_CLUSTER_BRIGHTNESS_NETHER);
	#endif

	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////ENDER//////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	
	#ifdef END

		// Lava / Flowing Lava
		if(	mc_Entity.x == 10248)
			lmCoord.x += 0.0667, mat=3.0, lmCoord.x += 0.0667, color.a *=0.40, color.rgb *= sqrt(END_LAVA_BRIGHTNESS);

		// Fire / Soul Fire
		if (mc_Entity.x ==  10249 || mc_Entity.x ==10252) 
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(FIRE_BRIGHTNESS_ENDER);

		// Soul CampFire / Soul Fire / Soul Torch
		if (mc_Entity.x == 10210) 
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(SCAMPFIRE_BRIGHTNESS_ENDER);

		// CampFire
		if (mc_Entity.x == 10215) 
			lmCoord.x = 0.5, color.a *= 1.0, color.rgb *= sqrt(CAMPFIRE_BRIGHTNESS_ENDER);

		// Lantern
		if (mc_Entity.x == 10251 || mc_Entity.x == 10254) 
			lmCoord.x = 0.860, color.a *= 1.0, color.rgb *= sqrt(LANTERN_BRIGHTNESS_ENDER);

		// Soul Lantern
		if (mc_Entity.x == 10226 || mc_Entity.x == 10253) 
			lmCoord.x = 0.750, color.a *= 1.0, color.rgb *= sqrt(SOUL_LANTERN_BRIGHTNESS_ENDER);

		// Shroomlight
		if (mc_Entity.x == 10217) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(SHROOMLIGHT_BRIGHTNESS_ENDER);

		// GlowStone
		if (mc_Entity.x == 10231) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(GLOWSTONE_BRIGHTNESS_ENDER);

		// Redstone Lamp
		if (mc_Entity.x == 10218) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(REDSTONE_LAMP_BRIGHTNESS_ENDER);
		
		// Sea Lantern
		if (mc_Entity.x == 10219) 
			lmCoord.x = 0.85, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(SEA_LANTERN_BRIGHTNESS_ENDER);

		#ifdef ADVANCED_MATERIALS
			#ifdef REDSTONE_BLOCK_EMISSIVE
			// Redstone Block
			if (mc_Entity.x == 10220 || mc_Entity.x == 10200)
				lmCoord.x = 0.5, mat=4.0 ,color.a *= 1.0, color.rgb *= sqrt(REDSTONE_BLOCK_BRIGHTNESS_OVERWORLD);
			#endif

			#ifdef LAPISLAZUL_BLOCK_EMISSIVE
			// Lapis Lazuli Block
			if (mc_Entity.x == 10221) 
				lmCoord.x = 0.5, mat=5.0 ,color.a *= 1.0, color.rgb *= sqrt(LAPIS_BLOCK_BRIGHTNESS_OVERWORLD);
			#endif
		#endif
		
		// Jack O Lantern
		if (mc_Entity.x == 10222) 
			lmCoord.x = 0.165, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(JACKOLANTERN_BRIGHTNESS_ENDER);

		// Torch / End Rod
		if (mc_Entity.x == 10214) 
			lmCoord.x = 0.855, mat=2.0 ,color.a *= 1.0, color.rgb *= sqrt(TORCH_ENDROD_BRIGHTNESS_ENDER);

		// Candle
		if (mc_Entity.x == 10257)
			lmCoord.x = 0.855, mat=6.0 ,color.a *= 1.0, color.rgb *= sqrt(CANDLE_BRIGHTNESS_ENDER);
		
		// Vine Berries
		if (mc_Entity.x == 10256)
			mat=7.0 ,color.a *= 1.0;

		// Spore_Blossom
		if (mc_Entity.x == 10112)
			mat=8.0 , color.a *= 1.0;

		// lichen
		if (mc_Entity.x == 10255)
			mat=11.0,color.a *= 1.0;

		// Pickle
		if (mc_Entity.x == 10259)
			mat=12.0,color.a *= 1.0;

		// Beacon
		if (mc_Entity.x == 10250)
			mat=13.0,color.a *= 1.0;

		// Small Ametyst
		if (mc_Entity.x == 10260)
			mat=14.0,color.a *= 1.0, color.rgb *= sqrt(SMALL_AMETYST_BRIGHTNESS_ENDER);
		// Medium Ametyst
		if (mc_Entity.x == 10261)
			mat=15.0,color.a *= 1.0, color.rgb *= sqrt(MEDIUM_AMETYST_BRIGHTNESS_ENDER);
		// Large Ametyst
		if (mc_Entity.x == 10262)
			mat=16.0,color.a *= 1.0, color.rgb *= sqrt(LARGE_AMETYST_BRIGHTNESS_ENDER);
		// Ametyst Cluster
		if (mc_Entity.x == 10263)
			mat=17.0,color.a *= 1.0, color.rgb *= sqrt(AMETYST_CLUSTER_BRIGHTNESS_ENDER);	
	#endif