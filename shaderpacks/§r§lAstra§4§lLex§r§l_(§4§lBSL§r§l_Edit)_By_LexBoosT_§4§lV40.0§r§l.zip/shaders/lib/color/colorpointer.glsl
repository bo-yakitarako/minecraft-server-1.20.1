//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

#ifdef GLOW_BERRIES
	if (berries >0.5){
			if (detectcolor.r >0.1 && detectcolor.g >0.77 && detectcolor.b > 0.10 && detectcolor.g < detectcolor.r){ 
		#ifdef NETHER
			emission = GLOW_BERRIES_GLOWING_POWER_NETHER;
		#endif
		#ifdef END
			emission = GLOW_BERRIES_GLOWING_POWER_ENDER;
		#endif
		#ifdef OVERWORLD
			emission = GLOW_BERRIES_GLOWING_POWER;
		#endif
		}
	}
#endif

#ifdef GLOW_SPORE_BLOSSOM
	if (spore_blossom >0.5){
		if (detectcolor.r >0.1 && detectcolor.g >0.20 && detectcolor.b < 0.32 && detectcolor.g < detectcolor.r){

			#ifdef NETHER
				emission = GLOW_SPORE_BLOSSOM_GLOWING_POWER_NETHER;
			#endif

			#ifdef END
				emission = GLOW_SPORE_BLOSSOM_GLOWING_POWER_ENDER;
			#endif

			#ifdef OVERWORLD
				emission = GLOW_SPORE_BLOSSOM_GLOWING_POWER;
			#endif
		}
	}
#endif

#ifdef GLOW_LICHEN
	if (lichen >0.5){
		if (detectcolor.r >0.25 && detectcolor.b > 0.15 && detectcolor.g > 0.10  && detectcolor.b < detectcolor.r){
			albedo.rgb = vec3(0.5725, 0.5608, 0.549);

			#ifdef NETHER
				emission = GLOW_LICHEN_GLOWING_POWER_NETHER;
			#endif

			#ifdef END
				emission = GLOW_LICHEN_GLOWING_POWER_ENDER;
			#endif

			#ifdef OVERWORLD
				emission = GLOW_LICHEN_GLOWING_POWER;
			#endif
		}
	}
#endif

#ifdef GLOW_PICKLE
	if (sea_pickle >0.5){
		if (detectcolor.g >0.8){
			albedo.rgb = vec3(0.8275, 0.8314, 0.4118);

			#ifdef NETHER
				emission = GLOW_PICKLE_GLOWING_POWER_NETHER;
			#endif

			#ifdef END
				emission = GLOW_PICKLE_GLOWING_POWER_ENDER;
			#endif

			#ifdef OVERWORLD
				emission = GLOW_PICKLE_GLOWING_POWER;
			#endif
			}
	}
#endif