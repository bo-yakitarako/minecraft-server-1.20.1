//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

vec4 netherNether=vec4(vec3(NETHER_NR,NETHER_NG,NETHER_NB)/255.,1.)*NETHER_NI;
vec4 netherValley=vec4(vec3(NETHER_VR,NETHER_VG,NETHER_VB)/255.,1.)*NETHER_VI;
vec4 netherCrimson=vec4(vec3(NETHER_CR,NETHER_CG,NETHER_CB)/255.,1.)*NETHER_CI;
vec4 netherWarped=vec4(vec3(NETHER_WR,NETHER_WG,NETHER_WB)/255.,1.)*NETHER_WI;
vec4 netherBasalt=vec4(vec3(NETHER_BR,NETHER_BG,NETHER_BB)/255.,1.)*NETHER_BI;

#ifdef NETHER_VANILLA

    vec4 netherColSqrt = vec4(normalize(fogColor), length(fogColor));

#else

#ifdef WEATHER_PERBIOME

    #if MC_VERSION <= 11701
        uniform float isValley,isCrimson,isWarped,isBasalt;
        float nBiomeWeight=isValley+isCrimson+isWarped+isBasalt;

        vec4 netherColSqrt=mix(
            netherNether,
            (
                netherValley*isValley+netherCrimson*isCrimson+
                netherWarped*isWarped+netherBasalt*isBasalt
            )/max(nBiomeWeight,.0001),
            nBiomeWeight
        );
    #endif

    #if MC_VERSION >= 11800
        uniform float isValley2,isCrimson2,isWarped2,isBasalt2;
        float nBiomeWeight=isValley2+isCrimson2+isWarped2+isBasalt2;

        vec4 netherColSqrt=mix(
            netherNether,
            (
                netherValley*isValley2+netherCrimson*isCrimson2+
                netherWarped*isWarped2+netherBasalt*isBasalt2
            )/max(nBiomeWeight,.0001),
            nBiomeWeight
        );
    #endif

#else
vec4 netherColSqrt=netherNether;
#endif
#endif

vec4 netherCol=netherColSqrt*netherColSqrt;