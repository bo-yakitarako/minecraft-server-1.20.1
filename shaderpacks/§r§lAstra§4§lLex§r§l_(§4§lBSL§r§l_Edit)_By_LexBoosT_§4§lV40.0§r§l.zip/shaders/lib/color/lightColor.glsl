//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

#if defined MOON_PHASE_LIGHTING && !defined UNIFORM_MOONPHASE
#define UNIFORM_MOONPHASE
uniform int moonPhase;
#endif

float CalcNightBrightness() {
	float nightBright = NIGHT_BRIGHTNESS;
	#ifdef MOON_PHASE_LIGHTING
		if (moonPhase == 0) nightBright *= NIGHT_LIGHTING_FULL_MOON;
		else if (!(moonPhase == 4)) nightBright *= NIGHT_LIGHTING_PARTIAL_MOON;
		else nightBright *= NIGHT_LIGHTING_NEW_MOON;
	#endif
	return nightBright;
}
float nightBrightness = CalcNightBrightness();

vec3 lightMorning    = vec3(LIGHT_MR,   LIGHT_MG,   LIGHT_MB)   * LIGHT_MI / 255.0;
vec3 lightMorning2   = vec3(LIGHT_MR2,  LIGHT_MG2,  LIGHT_MB2)  * LIGHT_MI2 / 255.0;

vec3 lightDay        = vec3(LIGHT_DR,   LIGHT_DG,   LIGHT_DB)   * LIGHT_DI / 255.0;
vec3 lightEvening    = vec3(LIGHT_ER,   LIGHT_EG,   LIGHT_EB)   * LIGHT_EI / 255.0;
vec3 lightNight      = vec3(LIGHT_NR,   LIGHT_NG,   LIGHT_NB)   * LIGHT_NI * (screenBrightness2*0.125 + 0.80) * 0.4 / 255.0 * nightBrightness;

vec3 ambientMorning  = vec3(AMBIENT_MR, AMBIENT_MG, AMBIENT_MB) * AMBIENT_MI * 1.1 / 255.0;
vec3 ambientDay      = vec3(AMBIENT_DR, AMBIENT_DG, AMBIENT_DB) * AMBIENT_DI * 1.1 / 255.0;
vec3 ambientEvening  = vec3(AMBIENT_ER, AMBIENT_EG, AMBIENT_EB) * AMBIENT_EI * 1.1 / 255.0;
vec3 ambientNight    = vec3(AMBIENT_NR, AMBIENT_NG, AMBIENT_NB) * AMBIENT_NI * (screenBrightness2*0.20 + 0.70) * 0.495 / 255.0 * nightBrightness;


#ifdef WEATHER_PERBIOME

	#if MC_VERSION <=11701
		uniform float isDesert, isMesa, isCold, isSwamp, isMushroom, isSavanna;
	#endif

	#if MC_VERSION >=11800
		uniform float isDesert2, isMesa2, isCold2, isSwamp2, isMushroom2, isSavanna2;
	#endif

	vec4 weatherRain     = vec4(vec3(WEATHER_RR, WEATHER_RG, WEATHER_RB) / 255.0, 1.0) * WEATHER_RI;
	vec4 weatherCold     = vec4(vec3(WEATHER_CR, WEATHER_CG, WEATHER_CB) / 255.0, 1.0) * WEATHER_CI;
	vec4 weatherDesert   = vec4(vec3(WEATHER_DR, WEATHER_DG, WEATHER_DB) / 255.0, 1.0) * WEATHER_DI;
	vec4 weatherBadlands = vec4(vec3(WEATHER_BR, WEATHER_BG, WEATHER_BB) / 255.0, 1.0) * WEATHER_BI;
	vec4 weatherSwamp    = vec4(vec3(WEATHER_SR, WEATHER_SG, WEATHER_SB) / 255.0, 1.0) * WEATHER_SI;
	vec4 weatherMushroom = vec4(vec3(WEATHER_MR, WEATHER_MG, WEATHER_MB) / 255.0, 1.0) * WEATHER_MI;
	vec4 weatherSavanna  = vec4(vec3(WEATHER_VR, WEATHER_VG, WEATHER_VB) / 255.0, 1.0) * WEATHER_VI;

	#if MC_VERSION <=11701
		float weatherWeight = isCold + isDesert + isMesa + isSwamp + isMushroom + isSavanna;
	#endif

	#if MC_VERSION >=11800
		float weatherWeight = isCold2 + isDesert2 + isMesa2 + isSwamp2 + isMushroom2 + isSavanna2;
	#endif

	#if MC_VERSION <=11701
	vec4 weatherCol = mix(
		weatherRain,
		(
			weatherCold  * isCold  + weatherDesert   * isDesert   + weatherBadlands * isMesa    +
			weatherSwamp * isSwamp + weatherMushroom * isMushroom + weatherSavanna  * isSavanna
		) / max(weatherWeight, 0.0001),
		weatherWeight
	);
	#endif

	#if MC_VERSION >=11800
	vec4 weatherCol = mix(
		weatherRain,
		(
			weatherCold  * isCold2  + weatherDesert   * isDesert2   + weatherBadlands * isMesa2    +
			weatherSwamp * isSwamp2 + weatherMushroom * isMushroom2 + weatherSavanna  * isSavanna2
		) / max(weatherWeight, 0.0001),
		weatherWeight
	);
	#endif

#else

vec4 weatherCol = vec4(vec3(WEATHER_RR, WEATHER_RG, WEATHER_RB) / 255.0, 1.0) * WEATHER_RI;

#endif

float mefade = 1.0 - clamp(abs(timeAngle - 0.5) * 8.0 - 1.5, 0.0, 1.0);
float dfade = 1.0 - timeBrightness; // fade du temps (ciel)

vec3 CalcSunColor(vec3 morning, vec3 day, vec3 evening) {
	vec3 me = mix(morning, evening, mefade);
	return mix(me, day, 1.0 - dfade * sqrt(dfade));
}

vec3 CalcLightColor(vec3 morning, vec3 day, vec3 afternoon, vec3 night, vec3 weatherCol) {
	vec3 me = mix(morning, afternoon, mefade);
	float dfadeModified = dfade * dfade;
	vec3 dayAll = mix(me, day, 1.0 - dfadeModified * dfadeModified);
	vec3 c = mix(night, dayAll, sunVisibility);
	c = mix(c, dot(c, vec3(0.299, 0.587, 0.114)) * weatherCol, rainStrengthS*0.6);
	return c * c;
}

vec3 lightSun   = CalcSunColor(lightMorning, lightDay, lightEvening);
vec3 ambientSun = CalcSunColor(ambientMorning, ambientDay, ambientEvening);

vec3 lightCol   = CalcLightColor(lightMorning,   lightDay,   lightEvening,   lightNight,
								 weatherCol.rgb * (screenBrightness2*0.1 + 0.9));
vec3 lightCol2   = CalcLightColor(lightMorning2,   lightDay,   lightEvening,   lightNight,
								 weatherCol.rgb * (screenBrightness2*0.1 + 0.9));
vec3 ambientCol = CalcLightColor(ambientMorning, ambientDay, ambientEvening, ambientNight,
								 weatherCol.rgb * (screenBrightness2*0.1 + 0.9));

////////////////////////////////////
/////Weather Rain / Snow Color/////
//////////////////////////////////

vec4 RainSnowColSqrt = vec4(vec3(RS_R, RS_G, RS_B) / 255.0, 1.0) * RS_I;
vec4 finalRainSnowCol = RainSnowColSqrt * RainSnowColSqrt;