//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

float GetNoise(vec2 pos){
return fract(sin(dot(pos,vec2(12.9898,4.1414)))*43758.5453);
}

vec3 DrawEndStars(vec3 color, vec3 viewPos) {
    vec3 wpos = vec3(gbufferModelViewInverse * vec4(viewPos, 1.0));
        if(wpos.y < 0) wpos = -wpos;
    vec3 planeCoord = 0.75 * wpos / (wpos.y + length(wpos.xz));

    float cosT = dot(normalize(viewPos), upVec);

    float NcosTM = abs(cosT);
          NcosTM = 1.0 - NcosTM;
          NcosTM = pow(NcosTM, (2.0 - NcosTM) * (3.0 - 0.8)) * 1.0;
          NcosTM = max(NcosTM, 0.0);
    
    vec2 coord = planeCoord.xz * 0.75 + cameraPosition.xz * 0.000125 ;
         coord = floor(coord*1024.0) / 1024.0;
    
    
    float multiplier = sqrt(sqrt(NcosTM)) * 6.0;
    float star = 1.0;
    if (NcosTM > 0.0) {
        star *= GetNoise(coord.xy);
        star *= GetNoise(coord.xy + 0.1);
        star *= GetNoise(coord.xy + 0.23);
    }
    star = max(star - 0.780, 0.0) * multiplier;
    
    #if NEW_ENDER_STARS == 1
    float star2 = 1.0;
    if (NcosTM > 0.0) {
        star2 *= GetNoise(coord.xy);
        star2 *= GetNoise(coord.xy + 0.4);
        star2 *= GetNoise(coord.xy + 0.86);
    }
    star2 = max(star2 - 0.840, 0.0) * multiplier;
    #endif

    #if NEW_ENDER_STARS == 1

    return color + star * pow(lightNight * 160, vec3(1.0, 0.0, 0.9176))
                 + star2 * pow(lightNight * 400, vec3(0.0, 0.0, 1.0));
    #else

    return color + star * pow(lightNight * 160, vec3(1.0));

    #endif
}

vec3 LostGlare(inout vec3 color, vec3 nViewPos) {
		float VoL = dot(normalize(nViewPos), lightVec);
		float visfactor = 0.03;
		float invvisfactor = 1.0 - visfactor;

		float visibility = clamp(VoL * 0.5 + 0.5, 0.0, 1.0);
		visibility = visfactor / (1.0 - invvisfactor * visibility) - visfactor;
		visibility = clamp(visibility * 1.015 / invvisfactor - 0.015, 0.0, 1.0);

			visibility = visibility * 0.055;

        vec3 glowCol = endCol2.rgb;
		glowCol = pow(glowCol * 1.0, vec3(2.3)) * LOST_GLARE_INTENSITY * 50;

        color += clamp(glowCol * visibility, 0.0, 1.0);

		return color;
	}
