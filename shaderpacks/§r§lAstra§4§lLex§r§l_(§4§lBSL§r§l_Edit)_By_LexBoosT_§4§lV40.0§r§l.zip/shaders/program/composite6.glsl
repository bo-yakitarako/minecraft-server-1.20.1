//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

//Settings//
#include "/lib/settings.glsl"

//Varyings//
varying vec2 texCoord;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

    //Uniforms//
    uniform float viewWidth, viewHeight, aspectRatio;

    #if AA > 0
        uniform float far, near;
    #endif

    uniform sampler2D colortex1;

    #if AA > 0
        #ifndef KEEP_AA_ON_WATER
            #if MC_VERSION >= 11605
                uniform sampler2D colortex8;
            #endif
        #endif
    #endif

    #if AA > 0
        uniform vec3 cameraPosition, previousCameraPosition;

        uniform mat4 gbufferPreviousProjection, gbufferProjectionInverse;
        uniform mat4 gbufferPreviousModelView, gbufferModelViewInverse;

        uniform sampler2D colortex2;
        uniform sampler2D colortex7;
        uniform sampler2D depthtex1;
    #endif

    //Optifine Constants//
    #ifdef LIGHTSHAFT
    const bool colortex1MipmapEnabled = true;
    #endif
    //Common Functions//

    #if AA > 0
    float GetLinearDepth(float depth) {
        return (2.0 * near) / (far + near - depth * (far - near));
    }
    #endif

    //Includes//

    #if AA == 1 || AA == 2
    #include "/lib/antialiasing/taa.glsl"
    #endif

    //Program//
    void main(){
        vec3 color = texture2DLod(colortex1, texCoord,0.0).rgb;
        
        #if AA > 0
            #ifndef KEEP_AA_ON_WATER
                #if MC_VERSION >= 11605
                    bool water = texture2DLod(colortex8,texCoord,0.0).r > 0.5;
                #else
                    bool water = false;
                #endif
            #else
                    bool water = false;
            #endif
        #endif

        #if AA == 1 || AA == 2
        vec4 prev = vec4(texture2DLod(colortex2, texCoord,0.0).r, 0.0, 0.0, 0.0);
        if (!water){
            TAA(color, prev);
        }
        #endif

        /*DRAWBUFFERS:1*/
        gl_FragData[0] = vec4(color, 1.0);

        #if AA > 0

        /*DRAWBUFFERS:12*/
        gl_FragData[1]=vec4(prev);
        
        #endif
    }

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

    //Program//
    void main(){
        texCoord=gl_MultiTexCoord0.xy;
        
        gl_Position=ftransform();
    }

#endif