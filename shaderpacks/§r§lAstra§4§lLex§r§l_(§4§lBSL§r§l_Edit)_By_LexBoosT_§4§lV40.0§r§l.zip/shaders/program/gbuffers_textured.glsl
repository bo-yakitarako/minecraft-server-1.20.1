//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

//Settings//
#include "/lib/settings.glsl"

//Varyings//
varying vec2 texCoord, lmCoord;

varying vec3 normal;
varying vec3 sunVec, upVec, eastVec;

varying vec4 color;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform int frameCounter;
	uniform int isEyeInWater;
	uniform int heldItemId;
	uniform int heldItemId2;

	#ifdef DYNAMIC_HAND_LIGHT
		uniform int heldBlockLightValue;
		uniform int heldBlockLightValue2;
	#endif

	uniform float far, near;
	uniform float frameTimeCounter;
	uniform float blindFactor, nightVision;
	uniform float rainStrength;
	uniform float rainStrengthS;
	uniform float screenBrightness;
	uniform float viewWidth, viewHeight;

	uniform ivec2 eyeBrightnessSmooth;

	uniform sampler2D noisetex;

	uniform vec3 cameraPosition;

	uniform vec3 skyColor;
	uniform vec3 fogColor;

	uniform mat4 gbufferProjectionInverse;
	uniform mat4 gbufferModelViewInverse;
	uniform mat4 shadowProjection;
	uniform mat4 shadowModelView;

	uniform sampler2D texture;

	#if MC_VERSION >= 11700
		uniform ivec4 blendFunc;
	#endif

	#ifdef SOFT_PARTICLES
		uniform sampler2D depthtex0;
	#endif

	//Common Variables//

	float eBS = eyeBrightnessSmooth.y / 240.0;
	float eBS2 = clamp(pow(eBS,8.0),0.0,1.0);
	float sunVisibility  = clamp(dot( sunVec,upVec) + 0.0625, 0.0, 0.125) * 8.0;
	float moonVisibility = clamp(dot( -sunVec,upVec) + 0.0625, 0.0, 0.125) * 8.0;
	float screenBrightness2 = clamp(screenBrightness, 0.0, 1.0);

	#ifdef OVERWORLD
		vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
	#else
		vec3 lightVec = sunVec;
	#endif

	//Common Functions//
	float GetLuminance(vec3 color){
		return dot(color,vec3(0.299, 0.587, 0.114));
	}

	#ifdef SOFT_PARTICLES
		float GetLinearDepth(float depth) {
			return (2.0 * near) / (far + near - depth * (far - near));
		}
	#endif

	//Includes//
	#if defined NETHER || defined END
		#include "/lib/color/lightColor.glsl"
	#endif

	#include "/lib/color/blocklightColor.glsl"
	#include "/lib/color/dimensionColor.glsl"
	#include "/lib/color/skyColor.glsl"
	#include "/lib/color/waterColor.glsl"
	#include "/lib/util/dither.glsl"
	#include "/lib/atmospherics/waterFog.glsl"
	#include "/lib/util/spaceConversion.glsl"
	#include "/lib/atmospherics/sky.glsl"
	#include "/lib/atmospherics/fog.glsl"
	#include "/lib/lighting/forwardLighting.glsl"

	#if defined (OVERWORLD) && defined WATER_CAUSTICS
	#include "/lib/lighting/caustics.glsl"
	#endif

	//Program//
	void main(){
		vec4 albedo = vec4(0.0);
		vec4 albedoT = texture2D(texture, texCoord);
			albedo = albedoT * color;


		if (albedo.a > 0.0){
			vec2 lightmap = clamp(lmCoord, vec2(0.0), vec2(1.0));
			
			vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
			vec3 viewPos = ScreenToView(screenPos);
			vec3 worldPos = ViewToWorld(viewPos);
			float lViewPos = length(viewPos.xyz);
			
			#if MC_VERSION >= 11700
				if (blendFunc == ivec4(770, 1, 1, 0)) {
					albedo.a = albedoT.a * color.a * 0.2;
					lightmap = vec2(1.0);
				}
			#endif

			albedo.rgb = pow(albedo.rgb, vec3(2.2));
			
			#ifdef WHITE_WORLD
				#ifdef TEXTURESW
				albedo.rgb = vec3(0.5);
				#endif
			#endif

			#ifdef BLACK_WORLD
				#ifdef TEXTURESW
					albedo.rgb = vec3(0.0);
				#endif
			#endif
			
			float NoL = 1.0;
			NoL = clamp(dot(normal, lightVec) * 1.01 - 0.01, 0.0, 1.0);
			float NoU = clamp(dot(normal, upVec), -1.0, 1.0);
			float NoE = clamp(dot(normal, eastVec), -1.0, 1.0);
			float vanillaDiffuse = (0.25 * NoU + 0.75) + (0.667 - abs(NoE)) * (1.0 - abs(NoU)) * 0.15;
			vanillaDiffuse*= vanillaDiffuse;
			
			vec3 shadow = vec3(0.0);
			GetLighting(albedo.rgb, shadow, viewPos, lViewPos, worldPos, lightmap, 1.0, NoL, 1.0,
			1.0, 0.0, 0.0, 0.0, 1.0);
			
			albedo.rgb *= 2.0;

			#ifdef PARTICLES_VISIBILITY
				if (lViewPos < 2.0) albedo.a *= smoothstep(0.7, 2.0, lViewPos) + 0.0002;
			#endif
			
			#if defined FOG && MC_VERSION >= 11500
				Fog(albedo.rgb, viewPos);
			#endif
			
			#if defined WATER_CAUSTICS && defined OVERWORLD
				#include "/lib/lighting/causticsCall.glsl"
			#endif

		}else discard;
		
		#ifdef SOFT_PARTICLES
			float linearZ = GetLinearDepth(gl_FragCoord.z) * (far - near);
			float backZ = texture2D(depthtex0, gl_FragCoord.xy / vec2(viewWidth, viewHeight)).r;
			float linearBackZ = GetLinearDepth(backZ) * (far - near);
			
			float difference = clamp(linearBackZ - linearZ, 0.6, 1.0);
			difference = difference * difference * (3.0 - 2.0 * difference);
			
			float opaqueThreshold = fract(Bayer64(gl_FragCoord.xy) + frameTimeCounter * 8.0);
			
			if (albedo.a > 0.999) albedo.a *= float(difference > opaqueThreshold);
			else albedo.a *= difference;
		#endif
		
		
		
		/*DRAWBUFFERS:0*/
		gl_FragData[0] = albedo;

		#ifdef ADVANCED_MATERIALS
		/*DRAWBUFFERS:0361*/
		gl_FragData[1] = vec4(0.0, 0.0, 0.0, 1.0);
		gl_FragData[2] = vec4(0.0, 0.0, 0.0, 1.0);
		gl_FragData[3] = vec4(0.0, 0.0, 0.0, 1.0);
		#endif
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//

	uniform float frameTimeCounter;

	uniform vec3 cameraPosition;

	uniform mat4 gbufferModelView,gbufferModelViewInverse;

	#ifdef SOFT_PARTICLES
		uniform float far,near;
	#endif

	//Common Functions//
	#ifdef SOFT_PARTICLES
		float GetLinearDepth(float depth) {
		return (2.0 * near) / (far + near - depth * (far - near));
		}
		float GetLogarithmicDepth(float depth) {
			return -(2.0 * near / depth - (far + near)) / (far - near);
		}
	#endif

	//Common Variables//
	#ifdef OVERWORLD
		float timeAngleM = timeAngle;
	#else
		float timeAngleM = 0.25;
	#endif

	//Program//
	void main(){
		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
		
		lmCoord=(gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
		lmCoord = clamp((lmCoord - 0.03125) * 1.06667, vec2(0.0), vec2(0.9333, 1.0));
		
		normal=normalize(gl_NormalMatrix * gl_Normal);
		
		color=gl_Color;
		
		const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
		float ang=fract(timeAngleM - 0.25);
		ang=(ang+(cos(ang * 3.14159265358979) * - 0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		sunVec=normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) *2000.0, 1.0)).xyz);
		
		upVec=normalize(gbufferModelView[1].xyz);
		eastVec=normalize(gbufferModelView[0].xyz);
		
		gl_Position=ftransform();
		
		#ifdef SOFT_PARTICLES
			gl_Position.z=GetLinearDepth(gl_Position.z/gl_Position.w) * (far - near);
			gl_Position.z-= 0.25;
			gl_Position.z=GetLogarithmicDepth(gl_Position.z/(far - near)) * gl_Position.w;
		#endif

		gl_Position.z -= 0.000002;
	}

#endif