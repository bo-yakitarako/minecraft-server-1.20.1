//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

//Settings//
#include "/lib/settings.glsl"

//Varyings//
varying vec2 texCoord;
varying vec4 color;
varying vec4 position;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

    //Uniforms//
    uniform sampler2D texture;
    uniform int heldItemId;
    uniform float frameTimeCounter;
    uniform float rainStrengthS;

    #ifdef CONSISTENT_ENCHANT
        uniform ivec2 eyeBrightnessSmooth;
        uniform float rainStrength;
    #endif

    //Common Variables//

    #ifdef CONSISTENT_ENCHANT
        float night = (clamp((worldTime-13000.0)/300.0,0.0,1.0)-clamp((worldTime-22800.0)/200.0,0.0,1.0));
        float cavelight = pow(eyeBrightnessSmooth.y / 240.0, 6.0) * 1.0 + (0.7 + 0.5 * night);
    #endif

    //Includes//
    #ifdef MAGICAL_GLINT
        #include "/lib/color/hue.glsl"
    #endif

    //Program//
    void main(){
        
        vec4 multiplier = color;
        vec4 albedo = texture2D(texture, texCoord ) * multiplier;
        
        #ifdef MODE_RAGE
            if(heldItemId==10267||heldItemId==10268||heldItemId==10276||heldItemId==10278||heldItemId==10283){
                multiplier = vec4 (1.0,0.0,0.0,1.0);
            }
            else
            {
                #endif
                #ifdef MAGICAL_GLINT
                multiplier = vec4(hue(frameTimeCounter * MAGICAL_GLINT_SPEED ), 1.0);
                #endif
                #ifdef MODE_RAGE
            }
        #endif

        #ifdef CONSISTENT_ENCHANT
            vec3 lighting = vec3(1.0+ (0.4*rainStrength - 0.4*rainStrength*night));
            lighting /= 0.8 - 0.5*night;
            lighting /= cavelight;
            
            albedo.rgb = pow(albedo.rgb * 0.5, lighting);

        #else
            albedo.rgb = pow(albedo.rgb,vec3(1.6));
            albedo*=0.25;
        #endif

        albedo.rgb *= GLINT_INTENSITY;

        /*DRAWBUFFERS:0*/
        gl_FragData[0]=albedo;
        
    }

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

    //Uniforms//

    uniform mat4 gbufferModelView;
    uniform mat4 gbufferModelViewInverse;

    uniform float frameTimeCounter;

    //Program//
    void main(){
            texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
            
            color=gl_Color;
            
            position=gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
            
            vec4 temppos=gl_ProjectionMatrix * gbufferModelView * position;
            
            if((temppos.z/temppos.w)<.56)//hand
            {
                
                #ifdef MOUVEMENTS_MAINS
                    position-=vec4(0.03 * sin(frameTimeCounter * 3.0 * SPEED_MOOVE), 0.015 * cos(frameTimeCounter * 4.0 * SPEED_MOOVE),0.0, 0.0) * gbufferModelView;
                #endif
                
                #ifdef MOUVEMENTS_MAINS_2
                    position.y+=sin(frameTimeCounter * 3.0 * SPEED_MOOVE) * 0.015;
                    position.z-=cos(frameTimeCounter * 4.0 * SPEED_MOOVE) * 0.0015;
                #endif
                
                position=gbufferModelView * position;
                
                position.z-=ADVANCE_HAND_POS;
                position.y+=ADVANCE_HAND_POS2;
                position.x+=DECALLAGE_MAINS;
                
                gl_Position=gl_ProjectionMatrix * position;
            }
            else
            {
                gl_Position = ftransform();
            }
            
    }
#endif