//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

//Settings//
#include "/lib/settings.glsl"

//Varyings//
varying vec2 texCoord;

varying vec3 normal;
varying vec3 sunVec, upVec;

varying vec4 position;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform int isEyeInWater;

	uniform float rainStrengthS;
	uniform float screenBrightness;

	uniform ivec2 eyeBrightnessSmooth;

	uniform sampler2D texture;

	//Common Variables//
	float eBS = eyeBrightnessSmooth.y / 240.0;
	float sunVisibility  = clamp(dot( sunVec,upVec) + 0.0625, 0.0, 0.125) * 8.0;
	float moonVisibility = clamp(dot( -sunVec,upVec) + 0.0625, 0.0, 0.125) * 8.0;
	float screenBrightness2 = clamp(screenBrightness, 0.0, 1.0);

	//Includes//
	#include "/lib/color/lightColor.glsl"

	//Program//
	void main(){
		#ifndef CLOUDS
			vec4 albedo = vec4(1.0, 1.0, 1.0, texture2D(texture, texCoord.xy).a);
			albedo.rgb = pow(albedo.rgb,vec3(2.2));
			
			float vanillaDiffuse = clamp(0.25 * dot(normal, upVec) + 0.75,0.5,1.0);
			albedo.rgb *= lightCol * (vanillaDiffuse * (0.3 * sunVisibility + 0.2));
			
			if (albedo.a > 0.1) {
				albedo.a = VANILLA_CLOUD_OPACITY;
				albedo.a *= albedo.a;
			}
		#else

			vec4 albedo = vec4(0.0);

		#endif

		/*DRAWBUFFERS:01*/
		
		gl_FragData[0] = albedo;
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	#if AA > 0
		uniform int frameCounter;

		uniform float viewWidth;
		uniform float viewHeight;
	#include "/lib/util/jitter.glsl"
	#endif

	uniform mat4 gbufferModelView;
	uniform mat4 gbufferModelViewInverse;

	//Common Variables//
	#ifdef OVERWORLD
		float timeAngleM = timeAngle;
	#else
		float timeAngleM = 0.25;
	#endif

	//Program//
	void main(){
		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
		
		normal=normalize(gl_NormalMatrix * gl_Normal);
		
		position=gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
		
		const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
		float ang=fract(timeAngleM - 0.25);
		ang=(ang+(cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		sunVec=normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);
		
		upVec=normalize(gbufferModelView[1].xyz);
		
		gl_Position=ftransform();
		
		#if AA > 0
			gl_Position.xy=TAAJitter(gl_Position.xy, gl_Position.w);
		#endif
	}

#endif