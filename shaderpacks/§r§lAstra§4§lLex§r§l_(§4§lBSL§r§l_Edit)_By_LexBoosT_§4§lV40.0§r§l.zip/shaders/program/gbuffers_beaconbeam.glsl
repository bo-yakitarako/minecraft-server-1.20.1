//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

//Settings//
#include "/lib/settings.glsl"

//Varyings//
varying vec2 texCoord;

varying vec4 color;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform sampler2D texture;

	//Includes//
	#include "/lib/color/blocklightColor.glsl"

	//Program//
	void main(){
		if (!gl_FrontFacing) discard;
		
		vec4 albedoT = texture2D(texture, texCoord);
		vec4 albedo = albedoT * color;
		
		albedo.rgb = pow(albedo.rgb, vec3(2.2));
		
		#ifdef WHITE_WORLD
			#ifdef BEACONW
				albedo.rgb = vec3(2.0);
			#endif
		#endif

		#ifdef BLACK_WORLD
			#ifdef BEACONW
				albedo.rgb = vec3(0.0);
			#endif
		#endif
		
		#ifdef EMISSIVE_BEACON_BEAM
			float emission = 0.0;

			#ifdef OVERWORLD
				float emissiveBeamMultiplier = BEACON_BEAM_EMISSIVE_OVERWORLD;
			#endif

			#ifdef NETHER
				float emissiveBeamMultiplier = BEACON_BEAM_EMISSIVE_NETHER;
			#endif

			#ifdef END
				float emissiveBeamMultiplier = BEACON_BEAM_EMISSIVE_ENDER;
			#endif

			emission = length(albedoT.rgb);
			emission *= emission;
			emission *= emission;
			if (color.a < 0.9) emission = pow2(emission * emission) * 0.01;
			else emission = emission * 0.1;

			vec3 beaconLighting = albedo.rgb * emission * 8 * emissiveBeamMultiplier * 0.25;

			albedo.rgb *= beaconLighting;

		#endif
		
			#if BEACON_BEAM_LAYER == 0
				albedo.a *= albedo.a;
				albedo.a *= albedo.a;
			#endif

			#if BEACON_BEAM_LAYER == 1
				albedo.a *= albedo.a;
				albedo.a *= albedo.a;
				albedo.a *= albedo.a;
			#endif

		/*DRAWBUFFERS:03*/

		gl_FragData[0] = albedo;

		#ifdef EMISSIVE_BEACON_BEAM
			gl_FragData[1]=vec4(0.,0.,0.,1.);
		#endif

		#ifdef ADVANCED_MATERIALS

		/*DRAWBUFFERS:0361*/

		#ifndef EMISSIVE_BEACON_BEAM
			gl_FragData[1]=vec4(0.0, 0.0, 0.0, 1.0);
		#endif

			gl_FragData[2]=vec4(0.0, 0.0, float(gl_FragCoord.z<1.0), 1.0);
			gl_FragData[3]=vec4(0.0, 0.0, 0.0, 1.0);
		#endif
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	#if AA > 0
		uniform int frameCounter;

		uniform float viewWidth;
		uniform float viewHeight;
	#endif

	//Includes//
	#if AA > 0
	#include "/lib/util/jitter.glsl"
	#endif

	//Program//
	void main(){
		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
		
		color=gl_Color;

		gl_Position=ftransform();
		
		#if AA > 0
			gl_Position.xy=TAAJitter(gl_Position.xy, gl_Position.w);
		#endif
	}

#endif