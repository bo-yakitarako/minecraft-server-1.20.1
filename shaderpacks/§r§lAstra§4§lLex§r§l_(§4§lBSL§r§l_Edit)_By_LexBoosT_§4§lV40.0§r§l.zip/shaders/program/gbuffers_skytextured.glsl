//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

//Settings//
#include "/lib/settings.glsl"

//Varyings//
varying vec2 texCoord;

varying vec3 upVec, sunVec;

varying vec4 color;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform sampler2D noisetex;
	uniform float nightVision;
	uniform float rainStrengthS;
	uniform float screenBrightness;
	uniform float viewWidth, viewHeight;

	uniform ivec2 eyeBrightnessSmooth;

	uniform mat4 gbufferProjectionInverse;

	uniform vec3 skyColor;
	uniform vec3 fogColor;

	uniform sampler2D texture;
	uniform sampler2D gaux1;

	uniform float frameTimeCounter;

	uniform vec3 cameraPosition;

	uniform mat4 gbufferModelViewInverse;

	#ifdef UNDERGROUND_SKY
		uniform int isEyeInWater;
	#endif

	#if MC_VERSION >= 11700 && defined OVERWORLD && defined VANILLA_SKYBOX && defined HORIZON_SUN_MOON
		uniform int renderStage;
	#endif

	#ifdef END
		#include "/lib/color/endColor.glsl"
	#endif

	//Common Variables//

	float eBS = eyeBrightnessSmooth.y / 240.0;
	float eBS2 = clamp(pow(eBS,8.0),0.0,1.0);
	float sunVisibility  = clamp(dot( sunVec,upVec) + 0.0625, 0.0, 0.125) * 8.0;
	float moonVisibility = clamp(dot( -sunVec,upVec) + 0.0625, 0.0, 0.125) * 8.0;
	float screenBrightness2 = clamp(screenBrightness, 0.0, 1.0);

	//Common Functions//

	float GetLuminance(vec3 color){
		return dot(color,vec3(0.299, 0.587, 0.114));
	}

	//Program//
	void main(){
		
		#if defined OVERWORLD && defined VANILLA_SKYBOX
			vec4 albedo = texture2D(texture, texCoord.xy);
			vec4 screenPos = vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z, 1.0);
			vec4 viewPos = gbufferProjectionInverse * (screenPos * 2.0 - 1.0);
			viewPos /= viewPos.w;

			vec3 nViewPos = normalize(viewPos.xyz);

			float NdotU = dot(nViewPos, upVec);

				#ifdef HORIZON_SUN_MOON

					#if MC_VERSION >= 11700
						if (renderStage > 3)
					#endif
					albedo.a *= clamp((NdotU+0.02)*10, 0.0, 1.0);
				#endif

				albedo *= color;

				albedo.rgb = pow(albedo.rgb, vec3(2.2 + sunVisibility * 2.2)) * (1.0 + sunVisibility * 4.0) * SKYBOX_BRIGHTNESS * albedo.a;

				#ifdef UNDERGROUND_SKY
					if (isEyeInWater<1){
					albedo.rgb *= mix(clamp((cameraPosition.y - 48.0) / 16.0, 0.0, 1.0), 1.0, eBS2);
					}
				#endif
		#else

			vec4 albedo = vec4(0.0);
		
		#endif

		#ifdef END
			#ifdef ENDER_SKY_COLOR_CUSTOM
				albedo.rgb = vec3(endColCustom.rgb * (0.035 + 0.02 * screenBrightness2));
				albedo.rgb = pow(albedo.rgb, vec3(1.0))* 10;
			#else
				albedo.rgb = vec3(endCol.rgb * (0.035 + 0.02 * screenBrightness2));
				albedo.rgb = pow(albedo.rgb, vec3(1.0)) * 10;
			#endif
		#endif
		
		/*DRAWBUFFERS:0*/
		gl_FragData[0]=clamp(albedo,0.0, 1.0);
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	uniform float frameTimeCounter;

	uniform mat4 gbufferModelView;

	#if AA > 0
		uniform int frameCounter;
		uniform float viewWidth,viewHeight;
	#endif

	//Common Variables//
	#if defined END || defined OVERWORLD
		#ifdef OVERWORLD
			float timeAngleM = timeAngle;
		#else
			float timeAngleM = 0.25;
		#endif
	#endif
	//Includes//
	#include "/lib/util/moonrot.glsl"

	#if AA > 0
	#include "/lib/util/jitter.glsl"
	#endif

	//Program//
	void main(){
		#if defined END || defined OVERWORLD

			texCoord=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
			
			color=gl_Color;
			
			gl_Position=ftransform();

		#endif

		#if defined OVERWORLD

			const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994),-sin(sunPathRotation * 0.01745329251994));
			float ang=fract(timeAngleM - 0.25);
			ang=(ang+(cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
			vec3 usunvec = vec3(-sin(ang), cos(ang) * sunRotationData);
			sunVec=normalize((gbufferModelView * vec4(usunvec * 2000.0, 1.0)).xyz);
			
			upVec=normalize(gbufferModelView[1].xyz);
			
			#if AA > 0
			gl_Position.xy=TAAJitter(gl_Position.xy, gl_Position.w);
			#endif

			#else
				#if !defined END
				vec4 color = vec4(0.0);
				gl_Position = color;
			#endif
		#endif
	}

#endif