//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

//Settings//
#include "/lib/settings.glsl"

//Varyings//
varying vec2 texCoord;

varying vec4 position;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform sampler2D texture;

	//Includes//

	//Program//
	void main(){
		vec4 albedo = texture2D(texture, texCoord);
		
		albedo.rgb = pow(albedo.rgb,vec3(2.2));
		
		#ifdef WHITE_WORLD
			#ifdef SPIDER_EYESW
				albedo.rgb = vec3(2.0);
			#endif
		#endif
		
		#ifdef COLORED_EYES
			#if SPIDER_EYES == 1
				albedo.rgb=vec3(1.0, 0.0, 0.0) * 4;
			
			#elif SPIDER_EYES == 2
				albedo.rgb=vec3(0.749, 0.0, 1.0) * 4;
			
			#elif SPIDER_EYES == 3
				albedo.rgb=vec3(0.0, 0.0157, 1.0) * 15;
			
			#elif SPIDER_EYES == 4
				albedo.rgb=vec3(0.0, 0.2667, 0.0431) * 4;
			
			#elif SPIDER_EYES == 5
				albedo.rgb=vec3(1.0, 0.9333, 0.0078) * 4;
			#endif
		
		#endif

		/*DRAWBUFFERS:0*/
		gl_FragData[0] = clamp(albedo, 0.0, 1.0);
		
		#ifdef ADVANCED_MATERIALS

		/*DRAWBUFFERS:0361*/
		gl_FragData[1]=vec4(0.0, 0.0, 0.0, 1.0);
		gl_FragData[2]=vec4(0.0, 0.0, 0.0, 1.0);
		gl_FragData[3]=vec4(0.0, 0.0, 0.0, 1.0);
		#endif
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//

	uniform mat4 gbufferModelView;
	uniform mat4 gbufferModelViewInverse;

	uniform float frameTimeCounter;

	//Program//
	void main(){
		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
		
		position=gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
		
		gl_Position=ftransform();

	}

#endif