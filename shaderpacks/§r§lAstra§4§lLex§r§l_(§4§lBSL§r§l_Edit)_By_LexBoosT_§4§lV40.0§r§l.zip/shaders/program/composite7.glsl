//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##   //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##   //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####    //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##     //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####    //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##   //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##   //
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####         //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##        //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #              //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####         //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##        //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##        //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####         //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////

//Settings//
#include "/lib/settings.glsl"

//Varyings//
varying vec2 texCoord;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

    //Uniforms//
    uniform float viewWidth, viewHeight;

    uniform sampler2D colortex1;

    #if AA > 0
        #ifndef KEEP_AA_ON_WATER
            #if MC_VERSION >= 11605
                uniform sampler2D colortex8;
            #endif
        #endif
    #endif

    //Common Functions//
    float GetLuminance(vec3 color) {
        return dot(color, vec3(0.299, 0.587, 0.114));
    }

    //Includes//

    #if AA == 1 || AA == 2
    #include "/lib/antialiasing/fxaa.glsl"
    #endif

    //Program//
    void main(){
        vec3 color = texture2D(colortex1, texCoord).rgb;

        #if AA > 0
            #ifndef KEEP_AA_ON_WATER
                #if MC_VERSION >= 11605
                    bool water = texture2D(colortex8,texCoord).r > 0.5;
                #else
                    bool water = false;
                #endif
            #else
                    bool water = false;
            #endif
        #endif

        #if AA == 1 || AA == 2
            if (!water)
                FXAA311(color);
        #endif

        /*DRAWBUFFERS:1*/
        gl_FragData[0] = vec4(color, 1.0);
    }

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

    //Program//
    void main() {
        texCoord = gl_MultiTexCoord0.xy;
        
        gl_Position = ftransform();
    }

#endif